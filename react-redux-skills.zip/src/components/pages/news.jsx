const News = () => {
	return (
		<div>
			<span>This is a NEWS page</span>
			{/* <Link to="/">Main page</Link> */}
		</div>
	);
};

export default News;
