import { useSelector, useDispatch } from "react-redux";
import { clearCurrentUser } from "../store/user-slice";
import { useNavigate } from "react-router-dom";

const Profile = () => {
	const currentUser = useSelector((state) => state.user.currentUser);
	const dispatch = useDispatch();
	const navigate = useNavigate();
	const onLogoff = () => {
		localStorage.removeItem("_rrs_isUserLogged");
		dispatch(clearCurrentUser());
		navigate("/");
	};
	return (
		<div>
			<label>
				User name: <span>{currentUser.name}</span>
			</label>
			<button onClick={onLogoff}>Logoff</button>
		</div>
	);
};

export default Profile;
