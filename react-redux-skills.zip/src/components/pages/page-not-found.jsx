const PageNotFound = () => {
	return (
		<div>
			<span>Page does not exist</span>
			{/* <Link to="/">Main page</Link> */}
		</div>
	);
};

export default PageNotFound;
