const PrivateNews = () => {
	return (
		<div>
			<span>This is a users PRIVATE NEWS page</span>
			{/* <Link to="/">Main page</Link> */}
		</div>
	);
};

export default PrivateNews;
