const Home = () => {
	return (
		<div>
			<span>Welcome to HOME page!</span>
			{/* <Link to="/">Main page</Link> */}
		</div>
	);
};

export default Home;
