import ModalLogin from "../modal/modal-login";
import { useState } from "react";
import { useSelector } from "react-redux";
import { NavLink } from "react-router-dom";

const User = () => {
	const [showModal, setShowModal] = useState(false);
	const currentUser = useSelector((state) => state.user.currentUser);

	const user = currentUser ? (
		<NavLink
			to="/profile"
			className="loggedIn"
		>
			{currentUser.name[0]}
		</NavLink>
	) : (
		<div
			onClick={() => {
				setShowModal(true);
			}}
		>
			Login
		</div>
	);

	return (
		<>
			<div className="menuSection">{user}</div>
			<ModalLogin
				showModal={showModal}
				setShowModal={setShowModal}
			/>
		</>
	);
};

export default User;
