import { useDispatch } from "react-redux";
import Menu from "../menu";
import User from "../user";
import "./App.css";
import RoutesTable from "./routes";
import { setCurrentUser } from "../store/user-slice";

export default function App() {
	const dispath = useDispatch();
	const isLogged = JSON.parse(localStorage.getItem("_rrs_isUserLogged"));
	if (isLogged) {
		dispath(setCurrentUser({ name: "Admin", password: "12345" }));
	}

	return (
		<>
			<header className="header">
				<nav className="navBar">
					<div className="menu">
						<Menu />
						<User />
					</div>
				</nav>
			</header>
			<main className="container">
				<RoutesTable />
				{/* <ul className="list"> // это эксперимент
					<li>1</li>
					<li>1</li>
					<li>1</li>
				</ul>
				<ul>
					<li>1</li>
					<li>1</li>
					<li>1</li>
				</ul> */}
			</main>
		</>
	);
}
