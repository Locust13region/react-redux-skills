import { createPortal } from "react-dom";
import { useState } from "react";
import { useDispatch } from "react-redux";
import { setCurrentUser } from "../store/user-slice";
import PropTypes from "prop-types";
import "./modal-login.css";
import { useNavigate } from "react-router-dom";

const ModalLogin = ({ showModal, setShowModal }) => {
	const userHardCode = { name: "Admin", password: "12345" };

	const navigate = useNavigate();

	let inputUserName = "";
	let inputUserPass = "";
	const [wrongNameOrPass, setwrongNameOrPass] = useState(false);

	const dispatch = useDispatch();

	if (!showModal) {
		return null;
	}
	const checkUserValid = () => {
		if (
			inputUserName === userHardCode.name &&
			inputUserPass === userHardCode.password
		) {
			setwrongNameOrPass(false);
			dispatch(setCurrentUser(userHardCode)); // пароль сохраняется в стор только в качестве ещё одного хранимого параметра
			localStorage.setItem("_rrs_isUserLogged", true);
			setShowModal(false);
			navigate("/profile");
		} else {
			setwrongNameOrPass(true);
		}
	};
	return (
		<>
			{createPortal(
				<div
					className="modalWrap"
					onClick={() => {
						setwrongNameOrPass(false);
						setShowModal(false);
					}}
				>
					<div
						className="modal"
						onClick={(e) => e.stopPropagation()}
					>
						<div className="modalTitle">Login</div>
						<div className="modalContent">
							<label>
								Username
								<input
									type="text"
									placeholder="Admin"
									onBlur={(e) => (inputUserName = e.target.value.toString())}
								></input>
							</label>
							<label>
								Password
								<input
									type="password"
									placeholder="12345"
									onBlur={(e) => (inputUserPass = e.target.value.toString())}
								></input>
							</label>
						</div>
						{wrongNameOrPass ? (
							<div className="modalMessage">wrong username or password</div>
						) : (
							<div className="modalMessage"></div>
						)}
						<button
							onClick={() => {
								inputUserName = "Admin";
								inputUserPass = "12345";
								checkUserValid();
							}}
						>
							Ok
						</button>
						<button
							onClick={() => {
								setwrongNameOrPass(false);
								setShowModal(false);
							}}
						>
							Cancel
						</button>
					</div>
				</div>,
				document.body
			)}
		</>
	);
};

ModalLogin.propTypes = {
	showModal: PropTypes.bool,
	setShowModal: PropTypes.func,
};

export default ModalLogin;
