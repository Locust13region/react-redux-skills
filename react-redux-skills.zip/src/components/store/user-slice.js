import { createSlice } from "@reduxjs/toolkit";

const initialState = {
	currentUser: "",
};

export const userSlice = createSlice({
	name: "currentUser",
	initialState,
	reducers: {
		setCurrentUser: (state, action) => {
			state.currentUser = action.payload;
		},
		clearCurrentUser: (state) => {
			state.currentUser = "";
		},
	},
});

export const { setCurrentUser, clearCurrentUser } = userSlice.actions;

export default userSlice.reducer;
